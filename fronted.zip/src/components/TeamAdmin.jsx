import axios from "axios";
import React, { useEffect, useState } from "react";

const TeamAdmin = () => {
    const [team, setTeam] = useState([]);
    const [editId, setEditId] = useState(null);
    const [formData, setFormData] = useState({
        name: "",
        role: "",
        description: "",
        image: null,
    });
    const [message, setMessage] = useState("");

    const API = "http://localhost:5000/api/team";

    // Fetch Team
    const fetchTeam = async () => {
        try {
            const res = await axios.get(API);
            setTeam(res.data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        fetchTeam();
    }, []);

    // Handle Text Change
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    // Handle File Change
    const handleFileChange = (e) => {
        setFormData({
            ...formData,
            image: e.target.files[0],
        });
    };

    // Submit
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const data = new FormData();
            data.append("name", formData.name);
            data.append("role", formData.role);
            data.append("description", formData.description);
            if (formData.image) {
                data.append("image", formData.image);
            }

            if (editId) {
                // UPDATE
                const res = await axios.put(`${API}/${editId}`, data);

                setTeam((prev) =>
                    prev.map((member) =>
                        member._id === editId ? res.data : member
                    )
                );

                setMessage("Team Member Updated Successfully!");
                setEditId(null);
            } else {
                // CREATE
                const res = await axios.post(API, data);

                setTeam((prev) => [res.data, ...prev]);
                setMessage("Team Member Added Successfully!");
            }

            setFormData({
                name: "",
                role: "",
                description: "",
                image: null,
            });

        } catch (error) {
            console.log(error);
            setMessage(error.response?.data?.message || "Something went wrong");
        }
    };

    const handleEdit = (member) => {
        setFormData({
            name: member.name,
            role: member.role,
            description: member.description,
            image: null,
        });

        setEditId(member._id);
    };

    // Delete
    const handleDelete = async (id) => {
        try {
            await axios.delete(`${API}/${id}`);
            fetchTeam();
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow max-w-2xl">
            <h2 className="text-xl font-semibold mb-4">Team Section</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter Name"
                    className="w-full border px-4 py-2 rounded-lg"
                />

                {/* Role */}
                <input
                    type="text"
                    name="role"
                    value={formData.role}
                    onChange={handleChange}
                    placeholder="Enter Role"
                    className="w-full border px-4 py-2 rounded-lg"
                />

                {/* Description */}
                <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Enter Description"
                    className="w-full border px-4 py-2 rounded-lg"
                />

                {/* Image */}
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="w-full border px-4 py-2 rounded-lg cursor-pointer"
                />

                <button
                    type="submit"
                    className="block bg-red-700 hover:bg-green-600 rounded-lg text-lg mx-auto hover:text-white p-2 cursor-pointer hover:scale-105 transition"
                >
                    {editId ? "Update Team Member" : "Add Team Member"}
                </button>

                {message && (
                    <p className="text-green-600 mt-2 text-sm text-center">
                        {message}
                    </p>
                )}
            </form>

            <hr className="my-6" />

            {/* Team List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {team.map((member) => (
                    <div key={member._id} className="border p-4 rounded-lg shadow">
                        <img
                            src={`http://localhost:5000/uploads/${member.image}`}
                            alt={member.name}
                            className="w-24 h-24 object-cover rounded-full mx-auto"
                        />
                        <h3 className="text-lg font-bold text-center mt-2">
                            {member.name}
                        </h3>
                        <p className="text-center text-gray-600">{member.role}</p>
                        <p className="text-sm text-center mt-2">
                            {member.description}
                        </p>
                        <div className="flex justify-between mt-5">
                        <button
                            onClick={() => handleEdit(member)}
                            className="block bg-green-600 text-white px-3 py-1 rounded mt-3 mx-auto hover:bg-green-800"
                        >
                            Edit
                        </button>

                        <button
                            onClick={() => handleDelete(member._id)}
                            className="block bg-red-600 text-white px-3 py-1 rounded mt-3 mx-auto hover:bg-red-800"
                        >
                            Delete
                        </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TeamAdmin;