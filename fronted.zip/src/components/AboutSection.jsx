import React, { useEffect, useState } from "react";
import axios from "axios";

const AboutSection = () => {
  const [heading, setHeading] = useState("");
  const [paragraph, setParagraph] = useState("");
  const [image, setImage] = useState(null);
  const [aboutList, setAboutList] = useState([]);
  const [editId, setEditId] = useState(null);

  const API = "http://localhost:5000/api/about";

  // ✅ Fetch About Data
 const fetchAbout = async () => {
  try {
    const res = await axios.get(API);

    if (Array.isArray(res.data)) {
      setAboutList(res.data);
    } else if (res.data) {
      setAboutList([res.data]);
    } else {
      setAboutList([]);
    }

  } catch (error) {
    console.error("Fetch error:", error);
    setAboutList([]);
  }
};

  useEffect(() => {
    fetchAbout();
  }, []);

  // ✅ SUBMIT (Add + Update Proper Integration)

 const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    const formData = new FormData();
    formData.append("heading", heading);
    formData.append("paragraph", paragraph);
    if (image) formData.append("image", image);

    if (editId) {
      const res = await axios.put(`${API}/${editId}`, formData);

      // Update UI without refetch
      setAboutList((prev) =>
        prev.map((item) =>
          item._id === editId ? res.data : item
        )
      );

      setEditId(null);
    } else {
      const res = await axios.post(API, formData);

      // Add new item to UI instantly
      setAboutList((prev) => [res.data, ...prev]);
    }

    setHeading("");
    setParagraph("");
    setImage(null);

  } catch (error) {
    console.error("Submit error:", error);
    alert("Something went wrong!");
  }
};

  // ✅ Delete
 const handleDelete = async (id) => {
  const confirmDelete = window.confirm(
    "Are you sure you want to delete this section?"
  );

  if (!confirmDelete) return;

  try {
    await axios.delete(`${API}/${id}`);

    // Remove from UI without refetch
    setAboutList((prev) =>
      prev.filter((item) => item._id !== id)
    );
  } catch (error) {
    console.error("Delete error:", error);
    alert("Delete failed!");
  }
};

  // ✅ Edit
  const handleEdit = (about) => {
    setHeading(about.heading);
    setParagraph(about.paragraph);
    setEditId(about._id);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">

        <h2 className="text-3xl font-bold mb-8 text-gray-800">
          About Us
        </h2>

        {/* Form */}
        <div className="bg-white shadow-lg rounded-2xl p-6 mb-10">
          <form onSubmit={handleSubmit} className="space-y-5">

            <input
              type="text"
              placeholder="Heading"
              value={heading}
              onChange={(e) => setHeading(e.target.value)}
              required
              className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <textarea
              placeholder="Paragraph"
              value={paragraph}
              onChange={(e) => setParagraph(e.target.value)}
              rows="4"
              required
              className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="file"
              accept="image/*"
              onChange={(e) => setImage(e.target.files[0])}
              className="w-full"
            />

            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition"
            >
              {editId ? "Update About" : "Add About"}
            </button>

          </form>
        </div>

        {/* About List */}
        <h3 className="text-2xl font-semibold mb-6 text-gray-700">
          About Sections
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {aboutList.map((about) => (
            <div
              key={about._id}
              className="bg-white shadow-md rounded-2xl p-6 hover:shadow-xl transition"
            >
              <img
                src={`http://localhost:5000/uploads/${about.image}`}
                alt=""
                className="w-full h-40 object-cover rounded-lg mb-4"
              />

              <h4 className="text-lg font-semibold text-gray-800">
                {about.heading}
              </h4>

              <p className="text-gray-600 text-sm mt-2">
                {about.paragraph}
              </p>

              <div className="flex justify-between mt-5">
                <button
                  onClick={() => handleEdit(about)}
                  className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm transition"
                >
                  Edit
                </button>

                <button
                  onClick={() => handleDelete(about._id)}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm transition"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default AboutSection;