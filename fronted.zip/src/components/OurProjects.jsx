import { useEffect, useState } from "react";
import React from "react";
import axios from "axios";

const API = "http://localhost:5000/api/projects";

export default function OurProjects() {
  const [projects, setProjects] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    image: null,
  });
  const [editId, setEditId] = useState(null);
  const [preview, setPreview] = useState(null);
  const [message, setMessage] = useState("");

  // Fetch Projects
  const fetchProjects = async () => {
    const res = await axios.get(API);
    setProjects(res.data);
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  // Handle Input
  const handleChange = (e) => {
    if (e.target.name === "image") {
      setFormData({ ...formData, image: e.target.files[0] });
      setPreview(URL.createObjectURL(e.target.files[0]));
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  // Submit (Add / Update)
  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = new FormData();
    data.append("title", formData.title);
    if (formData.image) {
      data.append("image", formData.image);
    }

    try {
      if (editId) {
        const res = await axios.put(`${API}/${editId}`, data);
        setProjects((prev) =>
          prev.map((p) => (p._id === editId ? res.data : p))
        );
        setMessage("Project Updated Successfully!");
        setEditId(null);
      } else {
        const res = await axios.post(API, data);
        setProjects([res.data, ...projects]);
        setMessage("Project Added Successfully!");
      }

      setFormData({ title: "", image: null });
      setPreview(null);
    } catch (error) {
      setMessage("Something went wrong");
    }
  };

  // Delete
  const handleDelete = async (id) => {
    await axios.delete(`${API}/${id}`);
    setProjects(projects.filter((p) => p._id !== id));
  };

  // Edit
  const handleEdit = (project) => {
    setFormData({
      title: project.title,
      image: null,
    });
    setEditId(project._id);
    setPreview(`http://localhost:5000/uploads/${project.image}`);
  };

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6 text-center">
        Projects Section
      </h1>

      {message && (
        <p className="text-center text-green-600 font-semibold mb-4">
          {message}
        </p>
      )}

      {/* FORM */}
      <form
        onSubmit={handleSubmit}
        className="bg-gray-100 p-6 rounded-lg shadow-md max-w-md mx-auto"
      >
        <input
          type="text"
          name="title"
          placeholder="Project Title"
          value={formData.title}
          onChange={handleChange}
          className="w-full p-2 mb-4 border rounded"
          required
        />

        <input
          type="file"
          name="image"
          onChange={handleChange}
          className="w-full mb-4"
        />

        {preview && (
          <img
            src={preview}
            alt="Preview"
            className="w-32 h-32 object-cover mb-4 rounded"
          />
        )}

        <button
          type="submit"
          className="w-full bg-red-600 hover:bg-green-600 text-white p-2 rounded transition"
        >
          {editId ? "Update Project" : "Add Project"}
        </button>
      </form>

      {/* PROJECT GRID */}
      <div className="grid md:grid-cols-3 gap-6 mt-10">
        {projects.map((project) => (
          <div
            key={project._id}
            className="relative rounded-xl overflow-hidden shadow-lg group"
          >
            <img
              src={`http://localhost:5000/uploads/${project.image}`}
              alt={project.title}
              className="w-full h-64 object-cover group-hover:scale-110 transition duration-300"
            />

            <div className="absolute bottom-0 bg-black bg-opacity-50 w-full text-white text-center py-2">
              {project.title}
            </div>

            <div className="absolute top-2 right-2 space-x-2">
              <button
                onClick={() => handleEdit(project)}
                className="bg-green-600 text-white px-2 py-1 rounded"
              >
                Edit
              </button>

              <button
                onClick={() => handleDelete(project._id)}
                className="bg-red-600 text-white px-2 py-1 rounded"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}