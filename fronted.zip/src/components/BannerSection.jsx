import React, { useEffect, useState } from "react";
import axios from "axios";

const BannerSection = () => {
  const [video, setVideo] = useState(null);
  const [title, setTitle] = useState("");
  const [buttonText, setButtonText] = useState("");
  const [banners, setBanners] = useState([]);
  const [editId, setEditId] = useState(null);

  const API = "http://localhost:5000/api/banner";

  // ✅ Fetch Banners
  const fetchBanners = async () => {
    const res = await axios.get(API);
    setBanners(res.data);
  };

  useEffect(() => {
    fetchBanners();
  }, []);

  // ✅ Submit (Add / Update)
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("buttonText", buttonText);
      if (video) formData.append("video", video);

      if (editId) {
        const res = await axios.put(`${API}/${editId}`, formData);

        // Update UI instantly without refetch
        setBanners((prev) =>
          prev.map((item) =>
            item._id === editId ? res.data : item
          )
        );

        setEditId(null);
      } else {
        const res = await axios.post(API, formData);

        // Add new banner to UI instantly
        setBanners((prev) => [res.data, ...prev]);
      }

      // Reset form
      setTitle("");
      setButtonText("");
      setVideo(null);

    } catch (error) {
      console.error("Submit failed:", error);
      alert("Something went wrong!");
    }
  };

  // ✅ Delete
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this banner?");

    if (!confirmDelete) return;

    try {
      await axios.delete(`${API}/${id}`);

      // Remove deleted banner from UI without refetch
      setBanners((prev) => prev.filter((banner) => banner._id !== id));

    } catch (error) {
      console.error("Delete failed:", error);
      alert("Something went wrong while deleting.");
    }
  };

  // ✅ Edit
  const handleEdit = (banner) => {
    setTitle(banner.title);
    setButtonText(banner.buttonText);
    setVideo(null); // clear old file
    setEditId(banner._id);

    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">

        <h2 className="text-3xl font-bold mb-8 text-gray-800">
          Banner Section
        </h2>

        {/* Form */}
        <div className="bg-white shadow-lg rounded-2xl p-6 mb-10">
          <form onSubmit={handleSubmit} className="space-y-5">

            <input
              type="text"
              placeholder="Banner Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="text"
              placeholder="Button Text"
              value={buttonText}
              onChange={(e) => setButtonText(e.target.value)}
              required
              className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="file"
              accept="video/*"
              onChange={(e) => setVideo(e.target.files[0])}
              className="w-full"
            />

            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition"
            >
              {editId ? "Update Banner" : "Add Banner"}
            </button>

          </form>
        </div>

        {/* Banner List */}
        <h3 className="text-2xl font-semibold mb-6 text-gray-700">
          All Banners
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {banners.map((banner) => (
            <div
              key={banner._id}
              className="bg-white shadow-md rounded-2xl p-6 hover:shadow-xl transition"
            >
              {banner.video && (
                <video
                  src={`http://localhost:5000/uploads/${banner.video}`}
                  controls
                  className="w-full h-40 object-cover rounded-lg mb-4"
                />
              )}

              <h4 className="text-lg font-semibold text-gray-800">
                {banner.title}
              </h4>

              <p className="text-gray-600 text-sm mt-2">
                Button: {banner.buttonText}
              </p>

              <div className="flex justify-between mt-5">
                <button
                  onClick={() => handleEdit(banner)}
                  className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm transition"
                >
                  Edit
                </button>

                <button
                  onClick={() => handleDelete(banner._id)}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm transition"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default BannerSection;